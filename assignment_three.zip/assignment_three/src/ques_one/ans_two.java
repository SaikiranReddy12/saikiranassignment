package ques_one;

public class ans_two {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
