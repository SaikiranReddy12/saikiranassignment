package ques_four;

public class NotSufficientBookException {

}
