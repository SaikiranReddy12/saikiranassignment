package ques_four;

public class ans_four {
	public static void main(String[] args) {

	}

}
