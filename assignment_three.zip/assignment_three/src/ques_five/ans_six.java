package ques_five;

public class ans_six {

}
