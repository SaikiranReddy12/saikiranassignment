package ques_six;

public class Ans_six {

}
