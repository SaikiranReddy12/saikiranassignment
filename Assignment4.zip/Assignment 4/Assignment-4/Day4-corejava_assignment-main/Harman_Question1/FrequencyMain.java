package Harman_Question1;

public class FrequencytMain
{
   static PrintFrequency f;

	public static void main(String[] args) {
	
        System.out.println("The frequency of each word in the file");		
		f=new PrintFrequency();
}
}
