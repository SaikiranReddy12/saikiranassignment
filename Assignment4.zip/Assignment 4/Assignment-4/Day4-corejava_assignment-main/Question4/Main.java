package Question4;

public class Main
{
	public static void main(String gg[])
	{
		PriorityQueueDemo pq=new PriorityQueueDemo();
		pq.sort1();
	}
}
