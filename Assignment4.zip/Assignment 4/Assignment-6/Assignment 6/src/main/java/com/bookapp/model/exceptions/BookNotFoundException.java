package com.bookapp.model.exceptions;

public class BookNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 4194505128085654190L;

	public BookNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
